(function() {
  "use strict";
  (function whatNextContentScript() {
    function looksSensitive() {
      if (document.querySelector('input[type="password"]')) return true;
      const path = location.pathname.toLowerCase();
      return ["/login", "/signin", "/checkout", "/payment", "/account/security"].some(
        (p) => path.includes(p)
      );
    }
    function getMetaDescription() {
      var _a;
      const meta = document.querySelector('meta[name="description"]');
      return ((_a = meta == null ? void 0 : meta.getAttribute("content")) == null ? void 0 : _a.slice(0, 300)) ?? "";
    }
    function sendSignal() {
      if (looksSensitive()) return;
      if (!document.title) return;
      chrome.runtime.sendMessage({
        type: "PAGE_SIGNAL",
        url: location.href,
        title: document.title.slice(0, 200),
        description: getMetaDescription()
      });
    }
    if (document.readyState === "complete") {
      sendSignal();
    } else {
      window.addEventListener("load", sendSignal, { once: true });
    }
    let lastTitle = document.title;
    const observer = new MutationObserver(() => {
      if (document.title !== lastTitle) {
        lastTitle = document.title;
        sendSignal();
      }
    });
    const titleEl = document.querySelector("title");
    if (titleEl) {
      observer.observe(titleEl, { childList: true });
    }
  })();
})();
